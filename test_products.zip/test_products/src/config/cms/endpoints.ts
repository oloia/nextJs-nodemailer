export const CMS_PARTNERS_ENDPOINT = '/items/test_products';
