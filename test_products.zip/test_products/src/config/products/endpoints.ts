export const PRODUCT_LIST_ENDPOINT = `/items/test_products`;
export const ASSETS_URL = (image: string) => `https://admin.energy5.com/assets/${image}`;

