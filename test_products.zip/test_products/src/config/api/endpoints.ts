export const API_ENV_ENDPOINT = '/api/environment';
