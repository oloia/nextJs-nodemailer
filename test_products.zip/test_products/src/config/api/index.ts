import {ENV} from "../env";


export const createApiBaseUrl = (): string => ENV.API_BASE_URL;
