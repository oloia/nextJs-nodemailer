export { default as DiContainer } from './DiContainer';
