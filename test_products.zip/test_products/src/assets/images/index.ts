export { default as CartImage } from 'src/assets/images/cart-image.jpg';
